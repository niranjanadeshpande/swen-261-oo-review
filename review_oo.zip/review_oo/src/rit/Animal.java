package rit;
/**
 * This Object represents all types of animals.
 * 
 * WHAT PRICIPLE IS VIOLATED?
 * <<your answer here>>
 */
public class Animal {

  public String move() {
    return null;
  }
}